var bg;
var p1;
var state=0;
var fenceimg;
var demonwalk;
var demonAttack;
var playerwalk;
var platformimg;
function preload(){
  platformimg=loadImage("platform1.png")
  bg=loadImage("bg1.png");
  fenceimg=loadImage("ground&houses_bg.png")
  demonwalk=loadAnimation("demon/Walk1.png","demon/Walk2.png","demon/Walk3.png","demon/Walk4.png","demon/Walk5.png","demon/Walk6.png")
  playerwalk=loadAnimation("player/run1.png","player/run2.png","player/run3.png","player/run4.png","player/run5.png","player/run6.png","player/run7.png","player/run8.png","player/run9.png")
  demonAttack=loadAnimation("demon/Attack1.png","demon/Attack2.png","demon/Attack3.png","demon/Attack4.png")
}
function setup() {
  createCanvas(displayWidth-30,displayHeight-50);
  p1=createSprite(50,200,50,50);
  p1.addAnimation("walk",playerwalk);
  p1.scale=0.2;

  fence=createSprite(displayWidth/2,displayHeight-100,displayWidth,150);
  fence.addImage(fenceimg);
  fence.visible=false;
 
  demon=createSprite(950,200,50,50);
 demon.addAnimation("walk",demonwalk);
 demon.addAnimation("attack",demonAttack);
 demon.visible=false;
 demon.setCollider("rectangle",0,0,50,80);



 platform=createSprite(displayWidth/2,displayHeight-300,displayWidth,50);
 platform.addImage(platformimg);
 platform.scale=2;
 platform.visible=false;
 platform.setCollider("rectangle",0,0,platform.width,80)
}

function draw() {
  background(bg);  
  if(keyWentDown("RIGHT_ARROW")){
    p1.velocityX=15;
  }
  if(keyWentUp("RIGHT_ARROW")){
    p1.velocityX=0;
  }
  if(keyWentDown("LEFT_ARROW")){
    p1.velocityX=-15;
  }
  if(keyWentUp("LEFT_ARROW")){
    p1.velocityX=0;
  }
  if(keyWentDown("UP_ARROW")){
    p1.velocityY=-10;
  }
  p1.velocityY+=0.5;
  if(p1.x>displayWidth-50 && state===0 ){
    p1.x=50;
    bg=loadImage("bg2.jpg");
    state++;

  }
  if(p1.x>displayWidth-50 && state===1 ){
    p1.x=50;
  bg=loadImage("clouds1.png");
 fence.visible=true;
 demon.visible=true;
 platform.visible=true;
demon.debug=true;
 demon.velocityX=-2;
 if(demon.x<displayWidth-200){
   demon.changeAnimation("attack")
 }
  }
  p1.collide(platform);
  demon.collide(platform);
  drawSprites();
  
}